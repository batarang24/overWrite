<?php
define('name','root');
define('password','');